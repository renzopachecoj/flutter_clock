# Sol/Luna Clock

Sol/Luna Clock has light and dark themes with a pair of custom wallpapers. It shows weather info with icons for differents weather conditions. It shows the date and upcoming alarm, too. It has an animated circle that grows with each passing second and shrinks at the start of every minute. 

<img src='sol_luna.gif' width='350'>

Light theme

<img src='sol_luna_light.png' width='350'>

Dark Theme

<img src='sol_luna_dark.png' width='350'>
