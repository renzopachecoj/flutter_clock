# Digital Clock

Sol/Luna Clock

<img src='sol_luna.gif' width='350'>

<img src='sol_luna_light.png' width='350'>

<img src='sol_luna_dark.png' width='350'>
